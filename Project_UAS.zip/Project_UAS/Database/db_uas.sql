-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 13, 2022 at 02:33 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_uas`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(10) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `username`, `password`) VALUES
(6, 'yuanita kristanto', 'Yun1717');

-- --------------------------------------------------------

--
-- Table structure for table `tb_takmir`
--

CREATE TABLE `tb_takmir` (
  `id_takmir` int(10) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `nomor` varchar(20) NOT NULL,
  `alamat` varchar(130) NOT NULL,
  `jabatan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_takmir`
--

INSERT INTO `tb_takmir` (`id_takmir`, `nama`, `nomor`, `alamat`, `jabatan`) VALUES
(1, 'Mustadi Arifin', '081122338877', 'Jalan Pasir Putih No.23', 'Ketua Takmir'),
(2, 'Jamali', '081100115544', 'Jalan Teluk Bayur II No.31', 'Wakil Takmir'),
(3, 'Ana Muhibuddin', '081155448877', 'Jalan Lovina No.2', 'Sekretaris Takmir'),
(4, 'Agus Supono', '084400115544', 'Jalan Teluk Bayur II No.12', 'Bendahara Takmir'),
(5, 'Khusnul Khotim', '081177115544', 'Jalan Atambua No.15', 'Sie Peribadatan'),
(6, 'Sayid Sudiyono', '081100113388', 'Jalan Sanur No.11', 'Sie Hari Besar Islam'),
(7, 'H. Syaifudin', '081100442244', 'Jalan Teluk Bayur II No.8', 'Sie Pembangunan');

-- --------------------------------------------------------

--
-- Table structure for table `ttamu`
--

CREATE TABLE `ttamu` (
  `id_tamu` int(10) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `nomor` varchar(15) NOT NULL,
  `alamat` varchar(130) NOT NULL,
  `gender` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ttamu`
--

INSERT INTO `ttamu` (`id_tamu`, `nama`, `nomor`, `alamat`, `gender`) VALUES
(1, 'M. Yafie Anwary R.', '081122334455', 'Perbon Tuban', 'Laki-Laki'),
(2, 'David Nasrulloh', '081133225544', 'Jombang, jatim', 'Laki - Laki'),
(3, 'Fi Fitriana', '080022334455', 'Pucangan, Tuban', 'Perempuan'),
(4, 'Ayussy Rahma A.', '081166225544', 'Mojokerto', 'Perempuan'),
(5, 'Yuanita Kristanto', '081166227788', 'Biak', 'Perempuan'),
(17, 'Nabila Dzul Afkar', '081144552233', 'Lamongan', 'Laki-Laki');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `tb_takmir`
--
ALTER TABLE `tb_takmir`
  ADD PRIMARY KEY (`id_takmir`);

--
-- Indexes for table `ttamu`
--
ALTER TABLE `ttamu`
  ADD PRIMARY KEY (`id_tamu`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tb_takmir`
--
ALTER TABLE `tb_takmir`
  MODIFY `id_takmir` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `ttamu`
--
ALTER TABLE `ttamu`
  MODIFY `id_tamu` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
