<?php
$server = "localhost";
$user = "root";
$pass = "";
$database = "db_uas";
$koneksi = mysqli_connect($server, $user, $pass, $database);
?>