<?php 
session_start();
if(isset($_SESSION["login"])){
	// header("Location : ../login.php");
	echo "<script> document.location='admin/homepage.php'; </script>";
	exit;
}

// Koneksi Database
require 'koneksi.php';

if (isset($_POST["login"])) {
	$username = $_POST["username"];
	$password = $_POST["password"];

	$result = mysqli_query($koneksi, "SELECT * FROM admin WHERE username ='$username'");

	//cek username
	if(mysqli_num_rows($result) === 1){

		//cek password
		$row = mysqli_fetch_assoc($result);
		// if(password_verify($password, $row["password"])){
		// 	header("Location : admin/homepage.html");
		// 	exit;
		// }
		if ($password == $row['password']){
			// header("Location : admin/homepage.html");
			// create session
			$_SESSION ["login"] = true;
			echo "
					<script> 
						alert('Login Sukses!!!');
						document.location.href='admin/homepage.php';
					</script>	";
			exit;
		}
		else{
			echo "
					<script> 
						alert('Gagal Login');
						document.location.href='login.php';
					</script>	";
		}
	}

	$error = true;
}

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>BAITURRAHMAN</title>
	<link rel="shortcut icon" href="iconme.ico" type="image/x-icon">
	<link rel="icon" href="iconme.ico" type="image/x-icon">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>

<body>
    <div class="header">					
		<h1><i class="fas fa-mosque"></i> MASJID BAITURRAHMAN</h1>
		<p><i class="fas fa-map-marker-alt"></i> Biak</p>
		<div id="flip"><i class="fas fa-arrow-alt-circle-down"></i></div>
		<div id="panel"><img src="image/foto_saya.jpg" width="200" height="200" style="border-radius: 50%;"/>
			<br>
			<p>Yuanita Kristanto</p>
			<p>19510004</p>
			<p>TPS</p>
		</div>	
	</div>
	<button class="tombol" onclick="side_open()"><i class="fas fa-angle-double-right fa-2x"></i></button>
	<nav class="menu" id="sideku">
		<button onclick="side_close()" class="btn btn-danger" style="float: right;">Close &times;</button><br>    
		<br><h4>CONTACT DEVELOP</h4>
    <ul>
		<li><i class="fas fa-user"></i> Yuanita Kristanto</li>
		<li><i class="fas fa-phone-alt"></i> 0812xxxxxxx</li>
		
	</ul>
    </nav>
	<nav class="navbar navbar-expand-sm bg-dark navbar-dark justify-content-center">
		<ul class="navbar-nav">
		<li class="nav-item">
			<a class="nav-link" href="homepage.html"><i class="fas fa-home"></i> Homepage  |</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="profile.html"><i class="fas fa-mosque"></i> Profil  |</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="jadwal.html"><i class="fas fa-clock"></i> Jadwal Sholat  |</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="takmir.php"><i class="fas fa-users"></i> Takmir  |</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="artikel.html"><i class="fas fa-book"></i> Artikel  |</a>
		</li>
		<div class="dropdown">
			<li class="nav-item">
				<a class="nav-link" href="#"> <i class="fas fa-address-book"></i> Buku Tamu</a> 
			</li>
			<div class="dropdown-content">
				<a href="buku_tamu.php"><i class="fas fa-scroll"></i> Form </a>
				<a href="buku_tabel.php"><i class="fas fa-table"></i> Tabel </a>
			</div>
		</div>
		</ul>
	</nav>
	<div style="background-color:#e6c29d;">
		<h1 style="text-align: center; color: #4E3620;">HALAMAN LOGIN</h1>			
		<div class="container";>
		<?php if( isset($error)) : ?>
			<p style="color: red; font-style: italic;">username / password salah</p>
		<?php endif ; ?>
			<!-- Awal Card Form -->
			<div class="card mt-3"style="background-color: #ffe2c4;">
				<div class="card-header bg-primary text-white">
					<div class="navbar navbar-expand-sm justify-content-center">
						<ul class="navbar-nav me-auto mb-2 mb-lg-0">
						<li class="nav-item">Login Admin</li> 
						</ul>
						<span class="navbar-text">
							<a href="homepage.html" class="btn btn-danger" type="reset" style="width:fit-content">&times;</a> 
						</span>
					</div>
				</div>
				
				<div class="card-body">
					<form method="POST" action=""  onreset="yaqueen()">
						<div class="form-group">
							<label>Username</label>
							<input type="text" name="username" id="username" 
							class="form-control" placeholder="Input Username anda di sini..." required>
						</div>
						<div class="form-group">
							<label>Password</label>
							<input type="password" name="password" id="password"
							class="form-control" placeholder="Input Password anda di sini..." required>
						</div>
						<br>
						<br>
						<div style="text-align: center;">
							<button type="submit" class="btn btn-success" name="login">
							<i class="fas fa-sign-in-alt"></i> Login</button>
							<button type="reset" class="btn btn-warning" name="breset">
							<i class="fas fa-backspace"></i> Kosongkan</button>
						</div>
						<div style="text-align: center;">
							<br>
							<p>Belum Memiliki Akun?</p>
							<a href="registrasi.php" type="reset" class="btn btn-primary">
								<i class="fas fa-user-edit"></i> Daftar
							</a>
						</div>
					</form>
				</div>
			</div>
			<!-- Akhir Card Form -->
		</div>
		<br>
		<br>
	</div>
	<footer class="footer">
		Copyright &copy; 2021 | Yuanita Kristanto | 19510004
	</footer>
</body>
</html>