


function hanyaAngka(evt) {
var charCode = (evt.which) ? evt.which : event.keyCode
if (charCode > 31 && (charCode < 48 || charCode > 57))
    return false;
    return true;
}

function yaqueen(){
alert('Data anda telah direset!')
}

//Panel Side Down and Up
$(document).ready(function(){
    $("#flip").click(function(){
    $("#panel").slideToggle("fast");
    });
});

// Sidebar open and close
$(document).ready(function(){
	$('.tombol').click(function(){
		$('.menu').toggleClass("slide-menu-tampil");
	});
});
function side_close() {
    document.getElementById("sideku").style.display = "none";
}
function side_open() {
    document.getElementById("sideku").style.display = "block";
}