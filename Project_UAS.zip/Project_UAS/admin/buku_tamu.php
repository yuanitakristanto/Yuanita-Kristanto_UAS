<?php
	session_start();
	if(!isset($_SESSION["login"])){
		// header("Location : ../login.php");
		echo "<script> document.location='../login.php'; </script>";
		exit;
	}
	// Koneksi Database
	require '../koneksi.php';

	//jika tombol simpan on click
	if(isset($_POST['bsimpan'])){
			//Data akan disimpan
			$simpan = mysqli_query($koneksi,"INSERT INTO ttamu (nama, nomor, alamat, gender)
				VALUES ('$_POST[tnama]',
						'$_POST[tnomor]',
						'$_POST[talamat]',
						'$_POST[tgender]')
			");
			if($simpan){ //Simpan data sukses
				echo "<script>
						alert('Simpan data sukses!');
						document.location='buku_tabel.php';
					</script>";
			}
			else{
				echo "<script>
						alert('Simpan data GAGAL!!!');
						document.location='buku_tabel.php';
					</script>";
			}
	}
	//pengujian jika tombol edit/hapus diklik
	if(isset($_GET['hal'])){
		//pengujian jika edit data
		if($_GET['hal']=="edit"){
			//tampilkan data yang diedit
			$tampil = mysqli_query($koneksi, "SELECT * FROM ttamu WHERE id_tamu ='$_GET[id]'");
			$data = mysqli_fetch_array($tampil);
			if($data){
				//jika data ditemukan, maka ditampung dalam variabel
				$vnama = $data['nama'];
				$vnomor = $data['nomor'];
				$valamat = $data['alamat'];
				$vgender = $data['gender'];
				
			}
		}
		else if ($_GET['hal'] == "hapus") {
		//Persiapan hapus data
		$hapus = mysqli_query($koneksi, "DELETE FROM ttamu WHERE id_tamu='$_GET[id]' ");
			if ($hapus) {
				echo "<script>alert('Hapus Data Suksess!!!'); 
				document.location='buku_tabel.php';
				</script>";
			}
		}
	}
	
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>BAITURRAHMAN</title>
	<link rel="shortcut icon" href="iconme.ico" type="image/x-icon">
	<link rel="icon" href="iconme.ico" type="image/x-icon">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>

<body>
    <div class="header">					
		<h1><i class="fas fa-mosque"></i> MASJID BAITURRAHMAN</h1>
		<p><i class="fas fa-map-marker-alt"></i> Biak</p>
		<div id="flip"><i class="fas fa-arrow-alt-circle-down"></i></div>
		<div id="panel"><img src="image/foto_saya.jpg" width="200" height="200" style="border-radius: 50%;"/>
			<br>
			<p>Yuanita Kristanto</p>
			<p>19510004</p>
			<p>TPS</p>
		</div>	
	</div>
	<button class="tombol" onclick="side_open()"><i class="fas fa-angle-double-right fa-2x"></i></button>
	<nav class="menu" id="sideku">
		<button onclick="side_close()" class="btn btn-danger" style="float: right;">Close &times;</button><br>    
		<br><h4>CONTACT DEVELOP</h4>
    <ul>
		<li><i class="fas fa-user"></i> Yuanita Kristanto</li>
		<li><i class="fas fa-phone-alt"></i> 0812xxxxxxx</li>
		
	</ul>
    </nav>
	<nav class="navbar navbar-expand-sm bg-dark navbar-dark justify-content-center">
		<ul class="navbar-nav">
		<li class="nav-item">
			<a class="nav-link" href="homepage.php"><i class="fas fa-home"></i> Homepage  |</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="profile.html"><i class="fas fa-mosque"></i> Profil  |</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="jadwal.html"><i class="fas fa-clock"></i> Jadwal Sholat  |</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="takmir.php"><i class="fas fa-users"></i> Takmir  |</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="artikel.html"><i class="fas fa-book"></i> Artikel  |</a>
		</li>
		<div class="dropdown">
			<li class="nav-item">
				<a class="nav-link" href="#"> <i class="fas fa-address-book"></i> Buku Tamu</a> 
			</li>
			<div class="dropdown-content">
				<a href="buku_tamu.php"><i class="fas fa-scroll"></i> Form </a>
				<a href="buku_tabel.php"><i class="fas fa-table"></i> Tabel </a>
			</div>
		</div>
		</ul>
	</nav>
	<div style="background-color:#e6c29d;">
		<h1 style="text-align: center; color: #4E3620;">Form Pengisian Buku Tamu</h1>			
		<div class="container";>
			<!-- Awal Card Form -->
			<div class="card mt-3"style="background-color: #ffe2c4;">
				<div class="card-header bg-primary text-white">
					Input Data Tamu
				</div>
				<div class="card-body">
					<form method="POST" action=""  onreset="yaqueen()">
						<div class="form-group">
							<label>Nama</label>
							<input type="text" name="tnama" value="<?=@$vnama?>" id="nama" 
							class="form-control" placeholder="Input Nama anda di sini..." required>
						</div>
						<div class="form-group">
							<label>Nomor HP</label>
							<input type="text" name="tnomor" value="<?=@$vnomor?>" onkeypress="return hanyaAngka(event)" id="nomor"
							class="form-control" placeholder="Input Nomor HP anda di sini..." required>
						</div>
						<div class="form-group">
							<label>Alamat</label>
							<textarea name="talamat" class="form-control" id="alamat"
							placeholder="Input Alamat anda di sini..." required><?=@$valamat?></textarea> 
						</div>
						<div class="form-group">
							<label>Jenis kelamin</label>
							<select class="form-control" name="tgender" id="gender" > 
								<option value="<?=@$vgender?>"><?=@$vgender?></option>
								<option value="Laki-Laki">Laki-Laki</option>
								<option value="Perempuan">Perempuan</option>
							</select>
						</div>
						<br>
						<br>
						<div style="text-align: center;">
							<button type="submit" class="btn btn-success" name="bsimpan">
							<i class="fas fa-save"></i> Simpan</button>
							<button type="reset" class="btn btn-warning" name="breset">
							<i class="fas fa-backspace"></i> Kosongkan</button>
						</div>
					</form>
				</div>
			</div>
			<!-- Akhir Card Form -->
		</div>
		<br>
		<br>
	</div>
	<footer class="footer">
		Copyright &copy; 2021 | Yuanita Kristanto | 19510004
	</footer>
</body>
</html>