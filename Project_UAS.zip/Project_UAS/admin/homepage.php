<?php
session_start();
	if(!isset($_SESSION["login"])){
		// header("Location : ../login.php");
		echo "<script> document.location='../login.php'; </script>";
		exit;
	}
	require '../koneksi.php';
?>
<!DOCTYPE html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>BAITURRAHMAN</title>
	<link rel="shortcut icon" href="iconme.ico" type="image/x-icon">
	<link rel="icon" href="iconme.ico" type="image/x-icon">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>

<body>
    <div class="header">					
		<h1><i class="fas fa-mosque"></i> MASJID BAITURRAHMAN</h1>
		<p><i class="fas fa-map-marker-alt"></i> Biak</p>
		<div id="flip"><i class="fas fa-arrow-alt-circle-down"></i></div>
		<div id="panel"><img src="image/foto_saya.jpg" width="200" height="200" style="border-radius: 50%;"/>
			<br>
			<p>Yuanita Kristanto</p>
			<p>19510004</p>
			<p>TPS</p>
		</div>	
	</div>
	<button class="tombol" onclick="side_open()"><i class="fas fa-angle-double-right fa-2x"></i></button>
	<nav class="menu" id="sideku">
		<button onclick="side_close()" class="btn btn-danger" style="float: right;">Close &times;</button><br>    
		<br><h4>CONTACT DEVELOP</h4>
    <ul>
		<li><i class="fas fa-user"></i> Yuanita Kristanto</li>
		<li><i class="fas fa-phone-alt"></i> 0812xxxxxxx</li>
		
	</ul>
    </nav>
	<nav class="navbar navbar-expand-sm bg-dark navbar-dark justify-content-center">
		<ul class="navbar-nav">
		<li class="nav-item">
			<a class="nav-link" href="homepage.php"><i class="fas fa-home"></i> Homepage  |</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="profile.html"><i class="fas fa-mosque"></i> Profil  |</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="jadwal.html"><i class="fas fa-clock"></i> Jadwal Sholat  |</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="takmir.php"><i class="fas fa-users"></i> Takmir  |</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="artikel.html"><i class="fas fa-book"></i> Artikel  |</a>
		</li>
		<div class="dropdown">
			<li class="nav-item">
				<a class="nav-link" href="#"> <i class="fas fa-address-book"></i> Buku Tamu</a> 
			</li>
			<div class="dropdown-content">
				<a href="buku_tamu.php"><i class="fas fa-scroll"></i> Form </a>
				<a href="buku_tabel.php"><i class="fas fa-table"></i> Tabel </a>
			</div>
		</div>
		</ul>
	</nav>
		
	<div style="background-color: #e6c29d;" class="isi">			
		<div class="container">
			<article style="text-align: center;">
				<br><h1>SELAMAT DATANG DI WEBSITE RESMI MASJID BAITURRAHMAN</h1>
				<br>
				<p>
					Masjid ini merupakan masjid yang digunakan para warga umat muslim Biak 
					untuk melakukan berbagai macam ibadah.
				</p>
				<p>
					Tak hanya untuk ibadah saja, masjid ini digunakan untuk tempat berkumpul,
					dan tempat untuk menyalurkan aspirasi masyarakat kemasjidan.
				</p>
				<p>
					Masjid ini memiliki remaja-remaja yang turut aktif dalam meramaikan dan memakmurkan masjid
				</p>
			</article>
			<div style="text-align: center;">
				<p style="text-align: center;"><img src="image/masjid.png" width="500" height="300"/></p>
				<br>
				<a href="logout.php" class="btn btn-danger" type="reset" style="width: fit-content; text-align: center;">
					<i class="fas fa-sign-out-alt"></i> Logout</a>
			</div>
			<br>
			<br>
		</div>
	<footer class="footer">
		Copyright &copy; 2021 | Yuanita Kristanto | 19510004
	</footer>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="js/mine.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery-3.6.0.js"></script>
</body>
</html>