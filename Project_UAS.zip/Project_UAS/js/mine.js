
function validasi() {
    var nama = document.getElementById("nama").value;
    var nomor = document.getElementById("nomor").value;
    var alamat = document.getElementById("alamat").value;
    var gender = document.getElementById("gender").value;
    if (nama != "" && nomor !="" && alamat!="" && gender !="" ) {
        return true;
    }
    else{
        alert('Anda harus mengisi data dengan lengkap !');
    }
}

function admin() {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    if (username != "" && password !="" ) {
        return true;
    }
    else{
        alert('Kolom Username dan Password tidak boleh kosong!');
    }
}

function hanyaAngka(evt) {
var charCode = (evt.which) ? evt.which : event.keyCode
if (charCode > 31 && (charCode < 48 || charCode > 57))
    return false;
    return true;
}

function yaqueen(){
alert('Data anda telah direset!')
}

//Panel Side Down and Up
$(document).ready(function(){
    $("#flip").click(function(){
    $("#panel").slideToggle("fast");
    });
});

// Sidebar open and close
$(document).ready(function(){
	$('.tombol').click(function(){
		$('.menu').toggleClass("slide-menu-tampil");
	});
});
function side_close() {
    document.getElementById("sideku").style.display = "none";
}
function side_open() {
    document.getElementById("sideku").style.display = "block";
}